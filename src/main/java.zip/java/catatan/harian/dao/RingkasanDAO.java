/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package catatan.harian.dao;

/**
 *
 * @author ADUL RAFI
 */
public class RingkasanDAO {
    
}
