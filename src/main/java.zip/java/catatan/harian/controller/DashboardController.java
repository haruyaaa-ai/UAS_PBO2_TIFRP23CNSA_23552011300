package catatan.harian.controller;

import catatan.harian.dao.TransaksiDAO;
import catatan.harian.model.Transaksi;
import catatan.harian.model.User;
import java.net.URL;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

public class DashboardController implements Initializable {

    @FXML
    private Label welcomeLabel;
    @FXML
    private Button tambahButton;
    @FXML
    private Button hapusButton;
    @FXML
    private Button editButton;
    @FXML
    private TableView<Transaksi> tabelTransaksi;
    @FXML
    private TableColumn<Transaksi, LocalDate> kolomTanggal;
    @FXML
    private TableColumn<Transaksi, String> kolomKategori;
    @FXML
    private TableColumn<Transaksi, String> kolomDeskripsi;
    @FXML
    private TableColumn<Transaksi, String> kolomPemasukan;
    @FXML
    private TableColumn<Transaksi, String> kolomPengeluaran;

    private User currentUser;
    private final TransaksiDAO transaksiDAO = new TransaksiDAO();
    private final ObservableList<Transaksi> listTransaksi = FXCollections.observableArrayList();
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Menghubungkan setiap kolom tabel dengan properti di objek Transaksi
        kolomTanggal.setCellValueFactory(new PropertyValueFactory<>("tanggalTransaksi"));
        kolomDeskripsi.setCellValueFactory(new PropertyValueFactory<>("deskripsi"));

        // Kolom Kategori memerlukan penanganan khusus karena berasal dari objek Kategori
        kolomKategori.setCellValueFactory(cellData -> 
            new SimpleStringProperty(cellData.getValue().getKategori().getNamaKategori())
        );

        // Kolom Pemasukan dan Pengeluaran juga memerlukan format mata uang
        currencyFormat.setMaximumFractionDigits(0); // Menghilangkan desimal
        
        kolomPemasukan.setCellValueFactory(cellData -> {
            Transaksi trx = cellData.getValue();
            if ("pemasukan".equals(trx.getJenisTransaksi())) {
                return new SimpleStringProperty(currencyFormat.format(trx.getJumlah()));
            }
            return new SimpleStringProperty("");
        });
        
        kolomPengeluaran.setCellValueFactory(cellData -> {
            Transaksi trx = cellData.getValue();
            if ("pengeluaran".equals(trx.getJenisTransaksi())) {
                return new SimpleStringProperty(currencyFormat.format(trx.getJumlah()));
            }
            return new SimpleStringProperty("");
        });

        // Menetapkan data ke tabel
        tabelTransaksi.setItems(listTransaksi);
    }

    // Metode ini dipanggil dari LoginController untuk mengirim data user
    public void initData(User user) {
        currentUser = user;
        welcomeLabel.setText("Halo, " + currentUser.getNamaLengkap() + "!");
        loadData();
    }
    
    public void loadData() {
        // Muat data tabel
        listTransaksi.clear();
        listTransaksi.addAll(transaksiDAO.findByUser(currentUser.getId()));

        // Muat juga data ringkasan jika sudah Anda implementasikan
        // Jika belum, baris di bawah ini bisa ditambahkan nanti
        // RingkasanKeuangan ringkasan = ringkasanDAO.getRingkasan(currentUser.getId());
        // pemasukanLabel.setText(currencyFormat.format(ringkasan.getTotalPemasukan()));
        // pengeluaranLabel.setText(currencyFormat.format(ringkasan.getTotalPengeluaran()));
        // saldoLabel.setText(currencyFormat.format(ringkasan.getSaldoTotal()));
    }

    @FXML
    private void handleTambahButton(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/catatan/harian/view/FormTransaksi.fxml"));
            Parent root = loader.load();

            // Kirim data user dan controller ini ke FormTransaksiController
            FormTransaksiController controller = loader.getController();
            controller.initData(currentUser, this);

            Stage stage = new Stage();
            stage.setTitle("Tambah Transaksi Baru");
            stage.setScene(new Scene(root));

            // Modality.APPLICATION_MODAL membuat jendela utama tidak bisa diklik selama form ini terbuka
            stage.initModality(Modality.APPLICATION_MODAL);

            stage.showAndWait(); // Gunakan showAndWait untuk jendela modal

        } catch (IOException e) {
            e.printStackTrace();
            // Tampilkan dialog error jika gagal membuka form
        }
    }

    @FXML
    private void handleEditButton(ActionEvent event) {
        Transaksi selectedTransaksi = tabelTransaksi.getSelectionModel().getSelectedItem();

        if (selectedTransaksi == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Peringatan");
            alert.setHeaderText(null);
            alert.setContentText("Silakan pilih transaksi yang ingin Anda edit.");
            alert.showAndWait();
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/catatan/harian/view/FormTransaksi.fxml"));
            Parent root = loader.load();

            // Panggil initData untuk mode EDIT
            FormTransaksiController controller = loader.getController();
            controller.initData(currentUser, selectedTransaksi, this);

            Stage stage = new Stage();
            stage.setTitle("Edit Transaksi");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void handleHapusButton(ActionEvent event) {
        // 1. Ambil item yang dipilih dari tabel
        Transaksi selectedTransaksi = tabelTransaksi.getSelectionModel().getSelectedItem();

        // 2. Pastikan ada item yang dipilih
        if (selectedTransaksi == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Peringatan");
            alert.setHeaderText(null);
            alert.setContentText("Silakan pilih transaksi yang ingin Anda hapus terlebih dahulu.");
            alert.showAndWait();
            return;
        }

        // 3. Tampilkan dialog konfirmasi
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Konfirmasi Hapus");
        confirmAlert.setHeaderText("Anda akan menghapus transaksi berikut:");
        confirmAlert.setContentText("Tanggal: " + selectedTransaksi.getTanggalTransaksi() + "\nDeskripsi: " + selectedTransaksi.getDeskripsi());

        Optional<ButtonType> result = confirmAlert.showAndWait();

        // 4. Jika pengguna menekan tombol OK
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // Panggil metode delete dari DAO
            boolean sukses = transaksiDAO.delete(selectedTransaksi.getId());

            if (sukses) {
                // Jika berhasil, refresh tabel
                loadData();
            } else {
                // Jika gagal, tampilkan pesan error
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Error");
                errorAlert.setHeaderText(null);
                errorAlert.setContentText("Gagal menghapus transaksi dari database.");
                errorAlert.showAndWait();
            }
        }
    }
}